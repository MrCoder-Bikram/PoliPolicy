import type express from 'express';
import { app, ensureBackendReady } from '../backend/server.js';

export default async function handler(req: express.Request, res: express.Response) {
  try {
    const rawUrl = req.url || '/';
    const parsed = new URL(rawUrl, 'http://localhost');
    const rewrittenPath = parsed.searchParams.get('__path');
    if (rewrittenPath !== null) {
      parsed.searchParams.delete('__path');
      const qs = parsed.searchParams.toString();
      const cleanPath = rewrittenPath.replace(/^\/+/, '');
      req.url = cleanPath ? `/api/${cleanPath}${qs ? `?${qs}` : ''}` : `/api${qs ? `?${qs}` : ''}`;
    }

    await ensureBackendReady();
    return app(req, res);
  } catch (err) {
    console.error('Vercel API handler error:', err);
    res.status(500).json({
      error: err instanceof Error ? err.message : 'Serverless API initialization failed.',
    });
  }
}
